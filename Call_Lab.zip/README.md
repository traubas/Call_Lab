# Call_Lab
a system that lets you create and save English exercises as an HTML pages to the hdd.  

How to use:  
1. Run the server from your IDE (eclipse).  
2. open Call_Lab_Client/index.html file.  
3. create a cloze by adding lines and adding choice boxes.  
4. send data to server.  

server will create an html file from a template html and add functions from functions.txt file located in the  
Call_Lab_Server folder.  
The file location will be opened so you can click the file to see the results.
